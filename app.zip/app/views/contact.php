<?php $this->layout('master', ['title' => $title]) ?>

<h2>Contact page</h2>