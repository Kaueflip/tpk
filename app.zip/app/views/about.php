<?php $this->layout('master', ['title' => $title]) ?>

<h2>About page</h2>