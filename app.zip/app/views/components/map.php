<div class="container-fluid p-0" id="map">
  <img class="img-fluid" src="../assets/img/map.webp" alt="Mapa Tropikalya">
  <div class="position-relative offers-img-wrapper">
    <img class="position-absolute img-fluid" src="../assets/img/leaf.svg" alt="Leaf Element">
  </div>
</div>