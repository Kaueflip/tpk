<div class="container-fluid" id="offers">
  <div class="position-relative offers-img-wrapper">
    <img class="position-absolute img-fluid" src="../assets/img/bike.svg" alt="Bike Element">
  </div>
  <div class="container">
    <div class="row-custom justify-content-center banner-title z-3 position-relative">
      <h2><strong>Ofertas </strong>imperdíveis.</h2>
      <p>
        A melhor escolha em hotéis no coração de <strong>Balneário Camboriú</strong>,
        para uma estadia inteligente e com o máximo de conforto.
      </p>
    </div>
  </div>
</div>