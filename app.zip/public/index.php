<?php

use app\routes\Router;

require '../vendor/autoload.php';

Router::execute();
