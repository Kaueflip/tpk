<?php $this->layout("master"); ?>

<h1>About</h1>