<?php $this->layout("master"); ?>

<h1>Home</h1>