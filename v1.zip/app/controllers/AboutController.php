<?php

namespace app\controllers;

use app\controllers\Controller;

class AboutController
{
  public function index($params)
  {
    //var_dump($params->name);
    return Controller::view("about");
  }
}
